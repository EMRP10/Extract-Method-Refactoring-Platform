# Proactive Clone Recommendation

In this repository, the plugin proposed in the following paper is available.

N. Yoshida, S. Numata, E. Choi and K. Inoue, "Proactive Clone Recommendation System for Extract Method Refactoring," 2019 IEEE/ACM 3rd International Workshop on Refactoring (IWoR), Montreal, QC, Canada, 2019, pp. 67-70, https://doi.org/10.1109/IWoR.2019.00020.
